#   Copyright 2011 Alexander Naumov <alexander_naumov@opensuse.org>

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License Version 2 as
#   published by the Free Software Foundation.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.

from PyQt4 import QtGui, QtCore

class QuitButton(QtGui.QWidget):
	def __init__(self, parent=None):
		QtGui.QWidget.__init__(self, parent)

	        self.setGeometry(300, 300, 250, 150)
	        self.setWindowTitle('Network Settings')

	        quit = QtGui.QPushButton('Close', self)
	        quit.setGeometry(10, 10, 60, 35)

	        self.connect(quit, QtCore.SIGNAL('clicked()'),
		        QtGui.qApp, QtCore.SLOT('quit()'))

#app = QtGui.QApplication(sys.argv)
qb = QuitButton()
#qb.show()
#sys.exit(app.exec_())

